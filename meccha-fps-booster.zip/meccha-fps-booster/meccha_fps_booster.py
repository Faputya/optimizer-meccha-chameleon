"""
Meccha FPS Booster — tkinter edition
------------------------------------
Тёмная полупрозрачная панель для управления графическими настройками
MECCHA CHAMELEON (Unreal Engine 5).

Важно:
- Перед изменением конфигов полностью закройте игру.
- Исходные файлы сохраняются в резервную копию при первом применении.
- Optimization: включает пресет с отключёнными тенями и масштабом 50%.
- Shadow: отдельно переключает качество теней.
- Scale: отдельно переключает масштаб разрешения на 50%.
- При выключении Optimization восстанавливаются исходные файлы.

Проверяйте результат в игре: доступность и приоритет отдельных CVar зависят
от конфигурации конкретной сборки Unreal Engine.
"""

from __future__ import annotations

import configparser
import json
import os
import shutil
import stat
import sys
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import messagebox


APP_NAME = "MECCHA FPS BOOSTER"
GAME_CONFIG_RELATIVE = Path("Chameleon") / "Saved" / "Config"
CONFIG_DIR_CANDIDATES = ("Windows", "WindowsClient", "WindowsNoEditor", "WinGDK")
MANAGED_FILES = ("Engine.ini", "Scalability.ini", "GameUserSettings.ini")

# Общие настройки пресета. Shadow и Scale управляются отдельно ниже.
ENGINE_BASE_SETTINGS = {
    "r.Lumen.DiffuseIndirect.Allow": "0",
    "r.Lumen.Reflections.Allow": "0",
    "r.Lumen.HardwareRayTracing": "0",
    "r.DynamicGlobalIlluminationMethod": "0",
    "r.ReflectionMethod": "0",
    "r.RayTracing.ForceAllRayTracingEffects": "0",
    "r.DefaultFeature.AntiAliasing": "0",
    "r.AntiAliasingMethod": "0",
}

BG = "#08090C"
PANEL = "#101217"
BLOCK = "#14171D"
BORDER = "#292D36"
TEXT = "#F0F2F7"
MUTED = "#9299A8"
GREEN = "#35D07F"
BLUE = "#49A5FF"
OFF_GRAY = "#535966"
OFF_RED = "#D94D58"


def local_appdata() -> Path:
    """Возвращает путь к %LOCALAPPDATA%."""
    value = os.environ.get("LOCALAPPDATA")
    if not value:
        raise RuntimeError("Не найдена переменная LOCALAPPDATA.")
    return Path(value)


def booster_data_dir() -> Path:
    path = local_appdata() / "MecchaFpsBooster"
    path.mkdir(parents=True, exist_ok=True)
    return path


def backup_dir() -> Path:
    path = booster_data_dir() / "backup"
    path.mkdir(parents=True, exist_ok=True)
    return path


def state_path() -> Path:
    return booster_data_dir() / "state.json"


def load_state() -> dict:
    """Загружает состояние переключателей."""
    try:
        data = json.loads(state_path().read_text(encoding="utf-8"))
        return {
            "optimized": bool(data.get("optimized", False)),
            "shadow": bool(data.get("shadow", True)),
            "scale": bool(data.get("scale", False)),
        }
    except (OSError, json.JSONDecodeError, TypeError):
        return {"optimized": False, "shadow": True, "scale": False}


def save_state(state: dict) -> None:
    state_path().write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def find_config_dir() -> Path | None:
    """Ищет папку пользовательских конфигов игры."""
    base = local_appdata() / GAME_CONFIG_RELATIVE
    if not base.is_dir():
        return None

    for name in CONFIG_DIR_CANDIDATES:
        candidate = base / name
        if candidate.is_dir():
            return candidate

    for child in sorted(base.iterdir()):
        if child.is_dir() and any(child.glob("*.ini")):
            return child

    # Папка может появиться раньше .ini-файлов.
    return None


def clear_readonly(path: Path) -> None:
    if path.exists():
        path.chmod(stat.S_IWRITE | stat.S_IREAD)


def read_ini(path: Path) -> configparser.ConfigParser:
    """
    Читает INI с сохранением регистра ключей.
    ConfigParser может нормализовать форматирование исходного файла,
    поэтому резервная копия нужна для точного восстановления.
    """
    parser = configparser.ConfigParser(
        interpolation=None,
        strict=False,
        allow_no_value=True,
    )
    parser.optionxform = str
    if path.is_file():
        parser.read(path, encoding="utf-8")
    return parser


def write_ini(path: Path, parser: configparser.ConfigParser) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        parser.write(handle, space_around_delimiters=False)


def set_values(parser: configparser.ConfigParser, section: str, values: dict[str, str]) -> None:
    if not parser.has_section(section):
        parser.add_section(section)
    for key, value in values.items():
        parser.set(section, key, value)


def ensure_backup(config_dir: Path) -> None:
    """Создаёт резервную копию только один раз."""
    marker = backup_dir() / "created.txt"
    if marker.is_file():
        return

    for name in MANAGED_FILES:
        source = config_dir / name
        destination = backup_dir() / name
        missing_marker = backup_dir() / f"{name}.missing"

        if source.is_file():
            shutil.copy2(source, destination)
            if missing_marker.exists():
                missing_marker.unlink()
        else:
            missing_marker.write_text(
                "Файл отсутствовал до первого применения.\n",
                encoding="utf-8",
            )

    marker.write_text("ok\n", encoding="utf-8")


def apply_settings(config_dir: Path, state: dict) -> list[Path]:
    """
    Применяет текущие параметры, не затрагивая файлы установки игры.
    Shadow=True означает обычное качество теней; False — отключённые тени.
    Scale=True задаёт ResolutionQuality=50; False удаляет управляемые
    значения масштаба, чтобы движок мог использовать штатную настройку.
    """
    ensure_backup(config_dir)
    changed: list[Path] = []

    # Engine.ini — общие параметры пресета плюс CVar теней/масштаба.
    engine_path = config_dir / "Engine.ini"
    clear_readonly(engine_path)
    engine = read_ini(engine_path)

    engine_values = dict(ENGINE_BASE_SETTINGS)
    engine_values["r.ShadowQuality"] = "3" if state["shadow"] else "0"
    if state["scale"]:
        engine_values["r.ScreenPercentage"] = "50"
    else:
        engine_values.pop("r.ScreenPercentage", None)

    set_values(engine, "SystemSettings", engine_values)
    write_ini(engine_path, engine)
    changed.append(engine_path)

    # Scalability.ini — группы качества.
    scalability_path = config_dir / "Scalability.ini"
    clear_readonly(scalability_path)
    scalability = read_ini(scalability_path)

    scalability_values = {
        "sg.ShadowQuality": "3" if state["shadow"] else "0",
    }
    if state["scale"]:
        scalability_values["sg.ResolutionQuality"] = "50"
    else:
        scalability_values.pop("sg.ResolutionQuality", None)

    set_values(scalability, "ScalabilityGroups", scalability_values)
    write_ini(scalability_path, scalability)
    changed.append(scalability_path)

    # GameUserSettings.ini — UE обычно хранит выбранные группы здесь.
    gus_path = config_dir / "GameUserSettings.ini"
    if gus_path.is_file() or (backup_dir() / "GameUserSettings.ini").is_file():
        clear_readonly(gus_path)
        gus = read_ini(gus_path)

        gus_values = {
            "sg.ShadowQuality": "3" if state["shadow"] else "0",
        }
        if state["scale"]:
            gus_values["sg.ResolutionQuality"] = "50"
        else:
            gus_values.pop("sg.ResolutionQuality", None)

        set_values(gus, "ScalabilityGroups", gus_values)
        write_ini(gus_path, gus)
        changed.append(gus_path)

    # Не ставим Engine.ini в Read-only: это может мешать игре и лаунчеру
    # сохранять другие параметры. Резервная копия позволяет откатить правки.
    return changed


def restore_original(config_dir: Path) -> list[str]:
    """Восстанавливает исходные файлы или удаляет созданные утилитой."""
    actions: list[str] = []

    for name in MANAGED_FILES:
        target = config_dir / name
        backup = backup_dir() / name
        missing_marker = backup_dir() / f"{name}.missing"

        clear_readonly(target)
        if backup.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup, target)
            actions.append(f"Восстановлен {name}")
        elif missing_marker.is_file():
            if target.is_file():
                target.unlink()
                actions.append(f"Удалён созданный {name}")

    return actions


class AnimatedSwitch(tk.Canvas):
    """Кастомный переключатель на Canvas с плавным перемещением ползунка."""

    def __init__(
        self,
        master,
        variable: tk.BooleanVar,
        *,
        on_color: str = GREEN,
        off_color: str = OFF_GRAY,
        command=None,
        width: int = 66,
        height: int = 32,
        **kwargs,
    ):
        super().__init__(
            master,
            width=width,
            height=height,
            bg=BLOCK,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
            **kwargs,
        )
        self.variable = variable
        self.on_color = on_color
        self.off_color = off_color
        self.command = command
        self.switch_width = width
        self.switch_height = height
        self._animation_job = None
        self._position = 1.0 if variable.get() else 0.0

        self.bind("<Button-1>", self._clicked)
        self.bind("<space>", self._clicked)
        self.draw(self._position)

    def draw(self, position: float) -> None:
        """Рисует дорожку и кругляшок; position лежит в диапазоне 0..1."""
        self.delete("all")
        w, h = self.switch_width, self.switch_height
        margin = 2
        track_color = self.on_color if position >= 0.5 else self.off_color

        # Скруглённая дорожка имитируется центральным прямоугольником и кругами.
        r = (h - margin * 2) / 2
        x1, y1, x2, y2 = margin, margin, w - margin, h - margin
        self.create_rectangle(x1 + r, y1, x2 - r, y2, fill=track_color, outline="")
        self.create_oval(x1, y1, x1 + 2 * r, y2, fill=track_color, outline="")
        self.create_oval(x2 - 2 * r, y1, x2, y2, fill=track_color, outline="")

        knob_r = r - 2
        left = margin + 2 + knob_r
        right = w - margin - 2 - knob_r
        cx = left + (right - left) * position
        cy = h / 2

        # Тонкий контур создаёт ощущение глубины.
        self.create_oval(
            cx - knob_r - 1, cy - knob_r - 1,
            cx + knob_r + 1, cy + knob_r + 1,
            fill="#D8DCE5", outline="#FFFFFF",
        )
        self.create_oval(
            cx - knob_r, cy - knob_r,
            cx + knob_r, cy + knob_r,
            fill="#FFFFFF", outline="#FFFFFF",
        )

    def set_value(self, value: bool, animate: bool = True) -> None:
        self.variable.set(value)
        target = 1.0 if value else 0.0

        if self._animation_job is not None:
            self.after_cancel(self._animation_job)
            self._animation_job = None

        if not animate:
            self._position = target
            self.draw(target)
            return

        def step():
            difference = target - self._position
            if abs(difference) < 0.06:
                self._position = target
                self.draw(target)
                self._animation_job = None
                return
            self._position += difference * 0.38
            self.draw(self._position)
            self._animation_job = self.after(12, step)

        step()

    def _clicked(self, _event=None) -> None:
        new_value = not self.variable.get()
        self.set_value(new_value)
        if self.command:
            self.command(new_value)


class BoosterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("440x360")
        self.minsize(420, 340)
        self.configure(bg=BG)

        # Альфа-канал окна. На некоторых окружениях Tk/Windows атрибут
        # может быть недоступен; в таком случае остаётся обычный тёмный фон.
        try:
            self.attributes("-alpha", 0.70)
        except tk.TclError:
            pass

        self.config_dir = find_config_dir()
        self.state = load_state()
        self._busy = False

        self.optimization_var = tk.BooleanVar(value=self.state["optimized"])
        self.shadow_var = tk.BooleanVar(value=self.state["shadow"])
        self.scale_var = tk.BooleanVar(value=self.state["scale"])

        self._build_ui()
        self.refresh_ui()

    def _build_ui(self):
        outer = tk.Frame(self, bg=BG, padx=16, pady=14)
        outer.pack(fill="both", expand=True)

        header = tk.Frame(outer, bg=BG)
        header.pack(fill="x", pady=(0, 12))

        tk.Label(
            header,
            text="MECCHA",
            font=("Segoe UI", 19, "bold"),
            fg=TEXT,
            bg=BG,
        ).pack(anchor="w")

        tk.Label(
            header,
            text="CHAMELEON  /  PERFORMANCE CONTROL",
            font=("Segoe UI", 8, "bold"),
            fg=BLUE,
            bg=BG,
        ).pack(anchor="w", pady=(1, 0))

        self.status_label = tk.Label(
            header,
            text="●  READY",
            font=("Segoe UI", 9, "bold"),
            fg=GREEN,
            bg=BG,
        )
        self.status_label.pack(anchor="e", pady=(0, 2))

        self.rows_frame = tk.Frame(
            outer,
            bg=PANEL,
            highlightbackground=BORDER,
            highlightthickness=1,
            padx=8,
            pady=7,
        )
        self.rows_frame.pack(fill="x")

        self.optimization_switch = self._make_row(
            self.rows_frame,
            "Optimization",
            "Общий пресет низкой графики",
            self.optimization_var,
            self.on_optimization,
            GREEN,
        )
        self.shadow_switch = self._make_row(
            self.rows_frame,
            "Shadow",
            "Качество теней",
            self.shadow_var,
            self.on_shadow,
            BLUE,
        )
        self.scale_switch = self._make_row(
            self.rows_frame,
            "Scale",
            "Масштаб разрешения: 50%",
            self.scale_var,
            self.on_scale,
            BLUE,
        )

        footer = tk.Frame(outer, bg=BG)
        footer.pack(fill="x", pady=(12, 0))

        self.path_label = tk.Label(
            footer,
            text=self._path_text(),
            font=("Segoe UI", 8),
            fg=MUTED,
            bg=BG,
            justify="left",
            anchor="w",
            wraplength=380,
        )
        self.path_label.pack(fill="x", pady=(0, 8))

        buttons = tk.Frame(footer, bg=BG)
        buttons.pack(fill="x")

        self.open_button = tk.Button(
            buttons,
            text="ОТКРЫТЬ ПАПКУ",
            command=self.open_config_folder,
            bg=BLOCK,
            fg=TEXT,
            activebackground=BORDER,
            activeforeground=TEXT,
            relief="flat",
            bd=0,
            padx=12,
            pady=7,
            cursor="hand2",
            font=("Segoe UI", 8, "bold"),
        )
        self.open_button.pack(side="left")

        self.restore_button = tk.Button(
            buttons,
            text="ВОССТАНОВИТЬ",
            command=self.on_restore,
            bg="#27171B",
            fg="#FF929A",
            activebackground="#3B2026",
            activeforeground="#FFFFFF",
            relief="flat",
            bd=0,
            padx=12,
            pady=7,
            cursor="hand2",
            font=("Segoe UI", 8, "bold"),
        )
        self.restore_button.pack(side="right")

        tk.Label(
            outer,
            text="Игра должна быть закрыта перед применением настроек.",
            font=("Segoe UI", 8),
            fg="#777F8F",
            bg=BG,
        ).pack(anchor="w", pady=(10, 0))

    def _make_row(self, parent, title, subtitle, variable, command, color):
        row = tk.Frame(
            parent,
            bg=BLOCK,
            highlightbackground=BORDER,
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        row.pack(fill="x", pady=4)

        labels = tk.Frame(row, bg=BLOCK)
        labels.pack(side="left", fill="x", expand=True)

        tk.Label(
            labels,
            text=title,
            font=("Segoe UI", 11, "bold"),
            fg=TEXT,
            bg=BLOCK,
        ).pack(anchor="w")

        tk.Label(
            labels,
            text=subtitle,
            font=("Segoe UI", 8),
            fg=MUTED,
            bg=BLOCK,
        ).pack(anchor="w", pady=(1, 0))

        switch = AnimatedSwitch(
            row,
            variable,
            on_color=color,
            off_color=OFF_GRAY,
            command=command,
        )
        switch.pack(side="right", padx=(10, 0))
        return switch

    def _path_text(self) -> str:
        if self.config_dir:
            return f"CONFIG  •  {self.config_dir}"
        return "CONFIG  •  Не найдена. Запустите игру один раз и закройте её."

    def refresh_ui(self):
        self.path_label.configure(text=self._path_text())
        if self.state["optimized"]:
            self.status_label.configure(text="●  OPTIMIZED", fg=GREEN)
        else:
            self.status_label.configure(text="●  READY", fg=MUTED)

        self.optimization_switch.set_value(self.state["optimized"], animate=False)
        self.shadow_switch.set_value(self.state["shadow"], animate=False)
        self.scale_switch.set_value(self.state["scale"], animate=False)

    def require_config_dir(self) -> Path | None:
        self.config_dir = find_config_dir()
        self.path_label.configure(text=self._path_text())
        if self.config_dir is None:
            messagebox.showwarning(
                "Конфиги не найдены",
                "Запустите MECCHA CHAMELEON до главного меню, закройте игру и повторите попытку.",
                parent=self,
            )
            return None
        return self.config_dir

    def apply_and_save(self):
        """Применяет состояние; при ошибке не сообщает об успехе."""
        config_dir = self.require_config_dir()
        if config_dir is None:
            self.refresh_ui()
            return

        if self._busy:
            return
        self._busy = True
        try:
            changed = apply_settings(config_dir, self.state)
            save_state(self.state)
            self.status_label.configure(text="●  SETTINGS APPLIED", fg=GREEN)
            self.path_label.configure(text=self._path_text())
        except (OSError, configparser.Error, RuntimeError) as exc:
            messagebox.showerror(
                "Ошибка записи",
                f"Не удалось применить настройки:\n{exc}\n\n"
                "Закройте игру и проверьте права доступа к папке конфигов.",
                parent=self,
            )
            self.state = load_state()
            self.optimization_var.set(self.state["optimized"])
            self.shadow_var.set(self.state["shadow"])
            self.scale_var.set(self.state["scale"])
            self.refresh_ui()
        finally:
            self._busy = False

    def on_optimization(self, enabled: bool):
        if enabled:
            self.state["optimized"] = True
            self.state["shadow"] = False
            self.state["scale"] = True
            self.shadow_switch.set_value(False)
            self.scale_switch.set_value(True)
            self.apply_and_save()
        else:
            config_dir = self.require_config_dir()
            if config_dir is None:
                self.state["optimized"] = True
                self.refresh_ui()
                return
            if not (backup_dir() / "created.txt").is_file():
                self.state["optimized"] = False
                self.state["shadow"] = True
                self.state["scale"] = False
                save_state(self.state)
                self.refresh_ui()
                return
            try:
                restore_original(config_dir)
                self.state = {
                    "optimized": False,
                    "shadow": True,
                    "scale": False,
                }
                save_state(self.state)
                self.refresh_ui()
                self.status_label.configure(text="●  RESTORED", fg=BLUE)
            except OSError as exc:
                messagebox.showerror("Ошибка восстановления", str(exc), parent=self)
                self.state["optimized"] = True
                self.refresh_ui()

    def on_shadow(self, enabled: bool):
        self.state["shadow"] = enabled
        # При ручной настройке Shadow сохраняем текущий статус общего пресета,
        # но применяем новое значение теней.
        self.apply_and_save()

    def on_scale(self, enabled: bool):
        self.state["scale"] = enabled
        self.apply_and_save()

    def on_restore(self):
        config_dir = self.require_config_dir()
        if config_dir is None:
            return
        if not (backup_dir() / "created.txt").is_file():
            messagebox.showinfo(
                "Нет резервной копии",
                "Резервная копия ещё не создана: настройки этой утилитой не применялись.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Восстановить настройки",
            "Вернуть файлы конфигурации к состоянию перед первым применением?",
            parent=self,
        ):
            return

        try:
            actions = restore_original(config_dir)
            self.state = {"optimized": False, "shadow": True, "scale": False}
            save_state(self.state)
            self.refresh_ui()
            self.status_label.configure(text="●  RESTORED", fg=BLUE)
            messagebox.showinfo(
                "Готово",
                "\n".join(actions) if actions else "Файлы уже были в исходном состоянии.",
                parent=self,
            )
        except OSError as exc:
            messagebox.showerror("Ошибка восстановления", str(exc), parent=self)

    def open_config_folder(self):
        config_dir = self.require_config_dir()
        if config_dir is None:
            return
        try:
            os.startfile(config_dir)  # Windows: открыть папку в Проводнике
        except (OSError, AttributeError) as exc:
            messagebox.showerror("Не удалось открыть папку", str(exc), parent=self)


def main() -> int:
    try:
        app = BoosterApp()
        app.mainloop()
        return 0
    except Exception:
        try:
            crash_file = booster_data_dir() / "crash.log"
            crash_file.write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        raise


if __name__ == "__main__":
    sys.exit(main())
