@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PY=%LOCALAPPDATA%\Programs\Python\Python315\python.exe"
set "PYW=%LOCALAPPDATA%\Programs\Python\Python315\pythonw.exe"

if not exist "%PY%" (
    echo Python 3.15 не найден:
    echo   %PY%
    echo Установите Python 3.15 и отметьте "tcl/tk" и "Add python.exe to PATH".
    pause
    exit /b 1
)

echo Используем: %PY%
"%PY%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo Не удалось поставить зависимости.
    pause
    exit /b 1
)

if exist "%PYW%" (
    start "" "%PYW%" "%~dp0meccha_fps_booster.py"
) else (
    start "" "%PY%" "%~dp0meccha_fps_booster.py"
)
endlocal
