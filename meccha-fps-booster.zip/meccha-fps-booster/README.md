# Meccha FPS Booster

Внешняя утилита для MECCHA CHAMELEON (Unreal Engine 5). Она не патчит exe и не лезет в папку Steam — только правит пользовательские `.ini` в AppData.

## Куда вносятся изменения

Корень пользовательских конфигов UE5:

```text
%LOCALAPPDATA%\Chameleon\Saved\Config\Windows
```

Полный путь обычно такой:

```text
C:\Users\<ваш_логин>\AppData\Local\Chameleon\Saved\Config\Windows
```

Если папки `Windows` нет, утилита ищет `WindowsClient`, `WindowsNoEditor` или `WinGDK`.

| Файл | Зачем |
| --- | --- |
| `Engine.ini` | Консольные переменные рендера: выключение Lumen / GI / RT, `r.ScreenPercentage=50` |
| `Scalability.ini` | Группы качества `sg.ShadowQuality=0`, `sg.AntiAliasingQuality=0`, `sg.ResolutionQuality=50` |
| `GameUserSettings.ini` | Сюда UE5 реально сохраняет `sg.*`. Файл трогается, только если уже существует |

Бэкап оригиналов: `%LOCALAPPDATA%\MecchaFpsBooster\backup`

## Запуск

Нужен установленный Python 3.15 (у вас: `%LOCALAPPDATA%\Programs\Python\Python315\python.exe`). Игра должна быть закрыта.

Дважды щёлкните `run.bat`. Он сам поставит CustomTkinter и откроет окно утилиты.

## Как проверить

1. Запустите игру один раз до меню и закройте её (чтобы появилась папка конфигов).
2. Откройте утилиту → **Optimization: Off** → станет **On**.
3. Откройте папку конфигов кнопкой в окне и убедитесь, что в `Engine.ini` есть `[SystemSettings]` с `r.Lumen.*=0` и `r.ScreenPercentage=50`, а в `Scalability.ini` — `sg.ResolutionQuality=50`.
4. Запустите игру и сравните FPS (счётчик Steam / NVIDIA / AMD). Картинка станет грубее: без GI, без теней, половинный внутренний масштаб.
5. **Вернуть как было** восстанавливает файлы из бэкапа.
